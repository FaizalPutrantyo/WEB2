	<footer class="footer">
	  <div class="container" style="text-align:center;">
	  	<hr/>
        <span>Warung Belajar @<?php echo date('Y'); ?></span>
      </div>
    </footer>
  </body>
</html>
